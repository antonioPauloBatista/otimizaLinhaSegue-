# Guia de Configurações por Linha de Produção (`exemplos_linhas/`)

Este diretório contém amostras e mapeamentos de colunas (`config_colunas.json`) específicos para diferentes linhas de envasamento e fabricação da planta.

---

## 📌 Linhas Disponíveis

| Linha | Tipo de Embalagem / Aplicação | Vel. Nominal ECH (CPH) | Descrição do Processo |
| :---: | :--- | :---: | :--- |
| **`NS541`** | **Long Neck** (Garrafas de Vidro) | 60.000 | Linha de garrafas Long Neck de alta velocidade |
| **`UB512`** | **Lata** (Cans / Latas de Alumínio) | 60.000 | Linha de envasamento de latas de alumínio |
| **`AQ541`** | Linha de Envasamento AQ | 60.000 | Linha de garrafas retornáveis/descartáveis AQ |
| **`NS503`** | Linha de Envasamento NS | 52.700 | Linha de garrafas NS |
| **`PG502`** | Linha de Envasamento PG | 45.000 | Linha de garrafas PG |
| **`PG511`** | Linha de Envasamento PG | 50.000 | Linha de garrafas PG |

---

## ⚙️ Como Utilizar uma Linha Específica

Para rodar a otimização com as configurações de uma dessas linhas:

1. Copie o arquivo `config_colunas.json` da linha desejada para o diretório raiz do pacote:
   ```bash
   cp exemplos_linhas/NS541/config_colunas.json ./config_colunas.json
   ```

2. Execute o otimizador:
   ```bash
   python otimizador_cma_es_free.py
   ```

---

## 🔍 Estrutura do `config_colunas.json`

Cada linha possui nomes de tags no InfluxDB/SCADA para identificar os sensores de velocidade e acúmulo (%):

```json
{
  "Arquivo_Dados": "dados_completos_fabrica.csv",
  "Col_Buffer_Antes_Entrada": "accumulation_percentage_pre_eci_null",
  "Col_Buffer_Entrada": "accumulation_percentage_eci_to_filler_null",
  "Col_Buffer_Saida": "accumulation_percentage_filler_to_pasteurizer_null",
  "Col_Buffer_Pos_Saida": "accumulation_percentage_post_pasteurizer_null",
  "COL_V_ECH": "speed_actual_cph_null_filler_1",
  "Velocidade_Nominal_ECH": 60000,
  "Fator_Sobremarcha": 1.0,
  "Min_Modulacao": 0.8,
  "Max_Modulacao": 1.0,
  "Limite_Parada_Falta": 10.0,
  "Limite_Parada_Acumulo": 75.0
}
```

- **`Col_Buffer_*`**: Colunas do CSV correspondentes às porcentagens de ocupação de esteira (0% a 100%).
- **`COL_V_*`**: Colunas do CSV com as velocidades reais instantâneas registradas (em CPH).
- **`Velocidade_Nominal_ECH`**: Velocidade de projeto nominal da máquina central (Enchedora).
- **`Limite_Parada_Falta` / `Limite_Parada_Acumulo`**: Limites críticos de interrupção por buffer, gerados automaticamente via `analisar_limites_fisicos.py`.
