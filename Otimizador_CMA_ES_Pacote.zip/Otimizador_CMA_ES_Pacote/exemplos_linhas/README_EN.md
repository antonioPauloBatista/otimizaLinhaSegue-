# Production Line Configurations Guide (`exemplos_linhas/`)

This directory contains dataset samples and column mappings (`config_colunas.json`) tailored for different packaging and bottling lines across the plant.

---

## 📌 Available Lines

| Line Code | Packaging Type / Application | Nominal Filler Speed (CPH) | Process Description |
| :---: | :--- | :---: | :--- |
| **`NS541`** | **Long Neck** (Glass Bottles) | 60,000 | High-speed Long Neck glass bottle line |
| **`UB512`** | **Cans** (Aluminum Cans) | 60,000 | Aluminum can filling line |
| **`AQ541`** | AQ Bottling Line | 60,000 | Returnable/One-way glass bottle line |
| **`NS503`** | NS Bottling Line | 52,700 | NS glass bottle line |
| **`PG502`** | PG Bottling Line | 45,000 | PG glass bottle line |
| **`PG511`** | PG Bottling Line | 50,000 | PG glass bottle line |

---

## ⚙️ How to Use a Specific Line Configuration

To run the optimizer using the configuration for one of these lines:

1. Copy the `config_colunas.json` file from the desired line folder into the package root:
   ```bash
   cp exemplos_linhas/NS541/config_colunas.json ./config_colunas.json
   ```

2. Run the optimizer script:
   ```bash
   python otimizador_cma_es_free.py
   ```

---

## 🔍 `config_colunas.json` Field Definitions

Each line maps specific InfluxDB/SCADA tag names to track machine speeds and conveyor accumulation levels (%):

```json
{
  "Arquivo_Dados": "dados_completos_fabrica.csv",
  "Col_Buffer_Antes_Entrada": "accumulation_percentage_pre_eci_null",
  "Col_Buffer_Entrada": "accumulation_percentage_eci_to_filler_null",
  "Col_Buffer_Saida": "accumulation_percentage_filler_to_pasteurizer_null",
  "Col_Buffer_Pos_Saida": "accumulation_percentage_post_pasteurizer_null",
  "COL_V_ECH": "speed_actual_cph_null_filler_1",
  "Velocidade_Nominal_ECH": 60000,
  "Fator_Sobremarcha": 1.0,
  "Min_Modulacao": 0.8,
  "Max_Modulacao": 1.0,
  "Limite_Parada_Falta": 10.0,
  "Limite_Parada_Acumulo": 75.0
}
```

- **`Col_Buffer_*`**: CSV columns for buffer occupancy percentages (0% to 100%).
- **`COL_V_*`**: CSV columns for recorded actual machine speeds (in CPH).
- **`Velocidade_Nominal_ECH`**: Target nominal speed of the central machine (Filler).
- **`Limite_Parada_Falta` / `Limite_Parada_Acumulo`**: Physical stoppage thresholds derived via `analisar_limites_fisicos.py`.
