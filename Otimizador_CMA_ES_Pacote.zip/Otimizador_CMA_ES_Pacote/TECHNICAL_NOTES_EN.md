# Technical Notes & Architecture - CMA-ES Free Speed Optimizer

This document provides technical, mathematical, and control engineering foundations for the engineering team responsible for integrating, auditing, or deploying the optimizer in staging or production environments.

---

## 1. Algorithm Overview (CMA-ES)

The **CMA-ES (Covariance Matrix Adaptation Evolution Strategy)** is a stochastic, derivative-free optimization algorithm highly suited for non-linear, non-convex, medium-to-high dimensional continuous problems.

### Why CMA-ES for Line Speed Optimization?
- **Severe Non-Linearity**: Packaging flow dynamics involve conveyor saturations (0% to 100%), transport delays, and severe discontinuities caused by sudden upstream/downstream machine trips.
- **Derivative-Free Global Search**: The physical container transmission model lacks an explicit analytical gradient; CMA-ES continuously adapts its covariance matrix to explore the search space in the direction of maximum line efficiency and stability.

---

## 2. Physical Model & Buffer Dynamics

The script simulates a second-by-second discrete mass balance across 5 main machines and 4 intermediate buffer sections:

$$\text{Machines: } M_1 (\text{DPL}) \longrightarrow M_2 (\text{UIP}) \longrightarrow M_3 (\text{ECH - Filler}) \longrightarrow M_4 (\text{ROT/PZ}) \longrightarrow M_5 (\text{EPC})$$

$$\text{Buffers: } B_1 (M_1 \rightarrow M_2), \quad B_2 (M_2 \rightarrow M_3), \quad B_3 (M_3 \rightarrow M_4), \quad B_4 (M_4 \rightarrow M_5)$$

### Buffer State Equation (% Accumulation):
For each timestamp $t$:

$$B_i(t+1) = \text{clip}\left(B_i(t) + \frac{V_{\text{upstream}}(t) - V_{\text{downstream}}(t)}{C_i \cdot 3600} \cdot 100, \, 0, \, 100\right)$$

Where:
- $V(t)$: Instantaneous speed in CPH (containers per hour).
- $C_i$: Buffer capacity in total container units.

---

## 3. Objective Function (Cost Function)

The optimization searches for control parameters $\mathbf{x}$ to minimize a weighted multi-objective cost function:

$$\text{Minimize } J(\mathbf{x}) = w_1 \cdot \text{StoppagePenalty} + w_2 \cdot \text{ProductionLoss} + w_3 \cdot \text{SpeedVariability} + w_4 \cdot \text{BufferOverflowRisk}$$

### Cost Components:
1. **Starvation & Blockage Stoppage Penalty ($w_1$)**: Heavy penalty whenever $B_2 \le \text{Threshold}$ (starvation at filler inlet) or $B_3 \ge \text{Threshold}$ (blockage at filler outlet).
2. **Production Loss ($w_2$)**: Ensures the filler operates at or near target nominal speed ($V_{\text{nominal}}$) without sacrificing total line throughput.
3. **Speed Smoothness ($w_3$)**: Penalizes sharp speed ramps ($\Delta V = |V(t) - V(t-1)|$), extending motor life and reducing mechanical strain.
4. **Safe Buffer Zone ($w_4$)**: Encourages operation within ideal buffer bands (e.g., 30% to 70% occupancy).

---

## 4. Configuration Files

### `config_colunas.json`
Specifies tag names, nominal speeds, and physical stoppage thresholds:
```json
{
  "Arquivo_Dados": "dados_completos_fabrica.csv",
  "Col_Buffer_Antes_Entrada": "accumulation_percentage_pre_eci_null",
  "Col_Buffer_Entrada": "accumulation_percentage_eci_to_filler_null",
  "Col_Buffer_Saida": "accumulation_percentage_filler_to_pasteurizer_null",
  "Col_Buffer_Pos_Saida": "accumulation_percentage_post_pasteurizer_null",
  "COL_V_ECH": "speed_actual_cph_null_filler_1",
  "Velocidade_Nominal_ECH": 60000,
  "Limite_Parada_Falta": 10.0,
  "Limite_Parada_Acumulo": 75.0
}
```

> [!NOTE]
> **How are `Limite_Parada_Falta` and `Limite_Parada_Acumulo` derived?**
> They are automatically calculated by running **`analisar_limites_fisicos.py`** on historical plant datasets:
> - **`Limite_Parada_Falta` (e.g., 10.0%)**: Conveyor occupancy level at buffer B2 below which the filler starves (derived from the P10 percentile of starvation events).
> - **`Limite_Parada_Acumulo` (e.g., 75.0%)**: Conveyor occupancy level at buffer B3 above which the filler trips due to downstream blockage (derived from P90/P99 percentiles).

### `parametros_cma_es.json`
Defines CMA-ES hyper-parameters:
```json
{
  "sigma0": 0.2,
  "maxiter": 200,
  "popsize": 16,
  "weight_parada": 1000.0,
  "weight_producao": 1.0,
  "weight_suavidade": 0.5
}
```

---

## 5. Industrial Deployment Guidelines (Edge / SCADA / PLC)

For closed-loop or supervisory implementation:

1. **Shadow Mode (Offline / Backtesting)**:
   - Run `otimizador_cma_es_free.py` periodically on historical data (InfluxDB/PostgreSQL) to re-tune control thresholds whenever packaging formats or machine conditions change.

2. **Closed-Loop Control (Real-Time)**:
   - Deploy the tuned policy onto an edge gateway (e.g., Docker container running Python).
   - Recommended setpoint execution rate: every 1 to 5 seconds.
   - **Fail-Safe**: If edge communication fails or yields `NaN`, the PLC must immediately revert to standard PID/Cascade logic.
