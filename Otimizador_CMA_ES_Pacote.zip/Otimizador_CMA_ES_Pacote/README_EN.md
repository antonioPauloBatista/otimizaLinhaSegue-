# Line Speed Optimizer (CMA-ES Free)

This package contains the complete implementation of the **CMA-ES (Covariance Matrix Adaptation Evolution Strategy) Speed Optimizer** designed for flow optimization and line stabilization in industrial bottling and packaging operations.

---

## 📌 Package Contents

- **`otimizador_cma_es_free.py`**: Main simulation and optimization script. Performs continuous speed optimization for the central machine (Filler) and outputs comparative KPIs and plots.
- **`analisar_limites_fisicos.py`**: Statistical analysis tool used to identify exact conveyor accumulation thresholds (%) where filler stoppages occur.
- **`dados_completos_fabrica_exemplo.csv`**: Sample dataset from plant operation with the exact expected schema.
- **`config_colunas.json`**: Column mapping configuration for InfluxDB/SCADA tags, nominal speeds, and stoppage thresholds.
- **`exemplos_linhas/`**: Subdirectory containing pre-configured column mappings and sample data for 6 plant production lines (`NS541` - Long Neck, `UB512` - Cans, `AQ541`, `NS503`, `PG502`, `PG511`). See [`exemplos_linhas/README_EN.md`](file:///home/antonio/Projetos/OtimizadorSegue/Otimizador_CMA_ES_Pacote/exemplos_linhas/README_EN.md) for details.
- **`parametros_cma_es.json`**: Tunable hyper-parameters and control setpoints for CMA-ES.
- **`requirements.txt`**: Required Python packages for execution.
- **`ANOTACOES_TECNICAS.md`**: Detailed technical documentation on model architecture, mathematical cost function, operational constraints, and deployment guidelines.

---

## 🧰 Requirements & Installation

### Prerequisites
- Python **3.8+** (Python 3.10 or 3.11 recommended)

### Installing Dependencies

Install required packages via terminal:

```bash
pip install -r requirements.txt
```

---

## 🚀 How to Run

### 1. Simple Run (Sample / Simulated Data)
If no custom CSV file is provided, the script automatically uses the included sample dataset:

```bash
python otimizador_cma_es_free.py
```

### 2. Running with Real Plant Data for a Specific Line
1. Select the target production line from `exemplos_linhas/` (e.g., `NS541` for Long Neck or `UB512` for Cans).
2. Copy the line configuration to the root directory:
   ```bash
   cp exemplos_linhas/NS541/config_colunas.json ./config_colunas.json
   ```
3. Run the optimizer:
   ```bash
   python otimizador_cma_es_free.py
   ```

---

## 📊 Generated Output

Upon completion, the optimizer outputs:
1. **Console KPI Summary**: Production gains, buffer stoppage reductions, speed variations, and downtime metrics.
2. **Comparative Plots (`.png`)**: Daily time-series plots comparing historical speed vs. optimized speed and conveyor buffer levels.
3. **Optimized Dataset (`dados_projetados_otimizado.csv`)**: Time-series CSV containing recommended speed setpoints and simulated buffer states.

---

## ✉️ Contact & Support

For technical questions regarding optimization logic, CMA-ES convergence, or assistance with PLC/SCADA/InfluxDB/Grafana integration, refer to `ANOTACOES_TECNICAS.md` or contact the Process Engineering and Data Science team.
