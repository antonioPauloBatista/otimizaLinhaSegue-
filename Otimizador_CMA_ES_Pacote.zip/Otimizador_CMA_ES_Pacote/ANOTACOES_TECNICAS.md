# Anotações Técnicas e Arquitetura - Otimizador CMA-ES Free

Este documento traz a fundamentação técnica, matemática e de controle para a equipe especializada que irá integrar, auditar ou implantar o otimizador em ambiente de homologação/produção.

---

## 1. Visão Geral do Algoritmo (CMA-ES)

O **CMA-ES (Covariance Matrix Adaptation Evolution Strategy)** é um algoritmo de otimização estocástico, não baseado em gradientes, altamente eficiente para problemas contínuos e não lineares de média/alta dimensão.

### Por que o uso do CMA-ES nesta aplicação?
- **Não-Linearidade Severa**: O comportamento de acúmulo de pacotes/garrafas nas esteiras (buffers) envolve não-linearidades, saturações (0% a 100%) e descontinuidades causadas por paradas bruscas das máquinas de montante/jusante.
- **Busca Global sem Gradiente**: O modelo físico da linha de transmissão de garrafas não possui derivada analítica explícita simples em tempo real; o CMA-ES adapta a matriz de covariância para explorar o espaço de busca na direção de maior ganho de eficiência.

---

## 2. Modelo Físico e Dinâmica de Buffers

O script simula o balanço de massa discreto (segundo a segundo) ao longo da linha de envasamento composta por 5 máquinas principais e 4 buffers intermediários:

$$\text{Máquinas: } M_1 (\text{DPL}) \longrightarrow M_2 (\text{UIP}) \longrightarrow M_3 (\text{ECH - Enchedora}) \longrightarrow M_4 (\text{ROT/PZ}) \longrightarrow M_5 (\text{EPC})$$

$$\text{Buffers: } B_1 (M_1 \rightarrow M_2), \quad B_2 (M_2 \rightarrow M_3), \quad B_3 (M_3 \rightarrow M_4), \quad B_4 (M_4 \rightarrow M_5)$$

### Equação de Estado dos Buffers (% de Ocupação):
Para cada instante de tempo $t$:

$$B_i(t+1) = \text{clip}\left(B_i(t) + \frac{V_{\text{upstream}}(t) - V_{\text{downstream}}(t)}{C_i \cdot 3600} \cdot 100, \, 0, \, 100\right)$$

Onde:
- $V(t)$: Velocidade instantânea calculada em CPH (containers por hora).
- $C_i$: Capacidade estimada do buffer em número de garrafas/embalagens.

---

## 3. Função Objetivo (Cost Function)

A otimização busca um conjunto de parâmetros de controle (ex: setpoints de velocidade em função do estado dos buffers ou coeficientes de curva de atuação) ajustando o vetor $\mathbf{x}$.

A função objetivo combina múltiplos critérios ponderados:

$$\text{Minimizar } J(\mathbf{x}) = w_1 \cdot \text{PenalidadeParada} + w_2 \cdot \text{PerdaProducao} + w_3 \cdot \text{VariabilidadeVelocidade} + w_4 \cdot \text{RiscoEstouroBuffer}$$

### Componentes da Função de Custo:
1. **Penalidade por Paradas por Falta ou Acúmulo ($w_1$)**: Penalização severa quando $B_2 \le 0\%$ (falta na entrada da enchedora) ou $B_3 \ge 100\%$ (bloqueio na saída).
2. **Perda de Produção em Relação ao Nominal ($w_2$)**: Garante que o otimizador busque manter a enchedora na velocidade nominal desejada ($V_{\text{nominal}}$) sem reduzir a vazão global da fábrica.
3. **Suavidade / Variabilidade de Velocidade ($w_3$)**: Penaliza variações bruscas de velocidade no motor da enchedora ($\Delta V = |V(t) - V(t-1)|$), reduzindo o desgaste mecânico e o consumo de energia (estabilidade de processo).
4. **Manutenção do Buffer na Zona Segura ($w_4$)**: Incentiva a operação na faixa ideal (ex: entre 30% e 70% de ocupação).

---

## 4. Arquivos de Configuração

### `config_colunas.json`
Define os nomes das variáveis do sistema, taxas nominais e os limites críticos de parada da enchedora:
```json
{
  "Arquivo_Dados": "dados_completos_fabrica.csv",
  "Col_Buffer_Antes_Entrada": "accumulation_percentage_pre_eci_null",
  "Col_Buffer_Entrada": "accumulation_percentage_eci_to_filler_null",
  "Col_Buffer_Saida": "accumulation_percentage_filler_to_pasteurizer_null",
  "Col_Buffer_Pos_Saida": "accumulation_percentage_post_pasteurizer_null",
  "COL_V_ECH": "speed_actual_cph_null_filler_1",
  "Velocidade_Nominal_ECH": 60000,
  "Limite_Parada_Falta": 10.0,
  "Limite_Parada_Acumulo": 75.0
}
```

> [!NOTE]
> **Como esses valores (`Limite_Parada_Falta` e `Limite_Parada_Acumulo`) são encontrados?**
> Eles são derivados executando o script **`analisar_limites_fisicos.py`** na massa de dados históricos. 
> - **`Limite_Parada_Falta` (ex: 10.0%)**: É o nível de ocupação do buffer de entrada (B2) abaixo do qual a enchedora efetivamente para por falta de garrafas (calculado via percentil P10 das paradas por falta).
> - **`Limite_Parada_Acumulo` (ex: 75.0%)**: É o nível de ocupação do buffer de saída (B3) acima do qual a enchedora efetivamente bloqueia por acúmulo à jusante (calculado via percentil P90/P99 das paradas por acúmulo).


### `parametros_cma_es.json`
Define os parâmetros do otimizador CMA-ES:
```json
{
  "sigma0": 0.2,
  "maxiter": 200,
  "popsize": 16,
  "weight_parada": 1000.0,
  "weight_producao": 1.0,
  "weight_suavidade": 0.5
}
```

---

## 5. Diretrizes para Implantação Industrial (Edge / Scada / PLC)

Para utilizar o modelo em malha fechada ou supervisória:

1. **Modo Shadow (Offline / Backtesting)**:
   - Executar o script `otimizador_cma_es_free.py` semanalmente com historiado de dados (InfluxDB/PostgreSQL/CSV) para re-sintonizar os parâmetros de atuação conforme desgaste da máquina ou troca de formato de garrafa.

2. **Modo Malha Fechada (Online / Real-Time Control)**:
   - Extrair a política sintonizada pelo CMA-ES e executá-la no controlador de tempo real (ex: Python em IPC ou container Docker no Edge Gateway).
   - Frequência recomendada de inferência/cálculo de Setpoint: a cada 1 segundo ou 5 segundos.
   - **Fail-Safe**: Se a comunicação com o gateway falhar ou o algoritmo retornar `NaN`, o PLC deve assumir o controle PID/Cascade padrão imediatamente.

---

## 6. Parecer dos Agentes Especialistas

- **Control Engineer**: A suavização da aceleração ($\Delta V$) foi validada para evitar ressonância nos motores e choques térmicos/mecânicos na enchedora.
- **Process Specialist**: Garantido que os limites de intertravamento do PLC têm prioridade sobre o setpoint sugerido pelo otimizador.
- **Validation Engineer**: Recomenda-se realizar testes A/B alternando dias de operação com otimizador ligado e desligado para medição do indicador OEE.
