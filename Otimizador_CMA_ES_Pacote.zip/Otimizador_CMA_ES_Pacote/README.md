# Otimizador de Velocidade de Linha Industrial (CMA-ES Free)

Este pacote contém a implementação completa do **Otimizador de Velocidade baseado em CMA-ES (Covariance Matrix Adaptation Evolution Strategy)** para otimização do fluxo e estabilização de linhas de envasamento/produção industrial.

---

## 📌 Conteúdo do Pacote

- **`otimizador_cma_es_free.py`**: Script principal de simulação e otimização. Executa a otimização de velocidade (livre/suave) para o equipamento central (Enchedora/Filler) e gera métricas e gráficos comparativos.
- **`analisar_limites_fisicos.py`**: Script auxiliar de análise estatística para identificar os níveis exatos de acúmulo (%) em que a linha sofre paradas por falta/bloqueio no histórico.
- **`dados_completos_fabrica_exemplo.csv`**: Amostra de dados reais da fábrica com o cabeçalho e estrutura exatos esperados pelo script.
- **`config_colunas.json`**: Arquivo de configuração de mapeamento de colunas do CSV de dados de fábrica, taxas nominais e filtros de parada.
- **`exemplos_linhas/`**: Pasta contendo amostras de dados e arquivos de configuração (`config_colunas.json`) pré-configurados para 6 diferentes linhas da fábrica, incluindo **`NS541`** (Long Neck), **`UB512`** (Lata / Cans), `AQ541`, `NS503`, `PG502` e `PG511`. Consulte [`exemplos_linhas/README.md`](file:///home/antonio/Projetos/OtimizadorSegue/Otimizador_CMA_ES_Pacote/exemplos_linhas/README.md) para detalhes.
- **`parametros_cma_es.json`**: Hiperparâmetros ajustáveis do CMA-ES (tamanho da população `sigma`, iterações `max_iter`, pesos da função objetivo).
- **`requirements.txt`**: Dependências de bibliotecas Python necessárias para execução.
- **`ANOTACOES_TECNICAS.md`**: Detalhamento da arquitetura, formulação matemática da função objetivo, restrições operacionais e guia para integração/implantação industrial.

---

## 🧰 Requisitos e Instalação

### Pré-requisitos
- Python **3.8+** (recomendado Python 3.10 ou 3.11)

### Instalação das Dependências

Instale os pacotes necessários executando no terminal:

```bash
pip install -r requirements.txt
```

---

## 🚀 Como Executar

### 1. Execução Simplicada (Dados Simulados)
Caso não forneça o arquivo CSV de fábrica (`dados_completos_fabrica.csv`), o script gera automaticamente uma massa de dados simulada para validação e testes:

```bash
python otimizador_cma_es_free.py
```

### 2. Execução com Dados Reais da Fábrica
1. Coloque o arquivo de dados reais no formato `.csv` no mesmo diretório (ou ajuste a chave `"Arquivo_Dados"` em `config_colunas.json`).
2. Garanta que o mapeamento das colunas de buffer (% acúmulo) e de velocidades instantâneas no `config_colunas.json` corresponda ao cabeçalho do seu CSV.
3. Execute o script:

```bash
python otimizador_cma_es_free.py
```

---

## 📊 Resultados Gerados

Ao finalizar a execução, o otimizador gera:
1. **Relatório Técnico no Console**: Resumo de ganhos de produção, redução de paradas, variação de velocidade e tempo total de parada.
2. **Gráficos Comparativos (`.png`)**: Comparação temporal da velocidade original vs. velocidade otimizada e níveis de buffer ao longo dos turnos/dias.
3. **Arquivo de Dados Otimizados (`dados_projetados_otimizado.csv`)**: Série temporal com as novas velocidades recomendadas e os estados simulados dos buffers.

---

## ✉️ Contato e Suporte

Para dúvidas técnicas sobre a lógica de otimização, convergência do algoritmo CMA-ES ou suporte na integração com PLC/Scada/InfluxDB/Grafana, consulte o documento `ANOTACOES_TECNICAS.md` ou entre em contato com a equipe de Engenharia de Processo e Data Science.
